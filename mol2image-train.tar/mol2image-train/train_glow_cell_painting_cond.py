import sys
sys.path.append('../')

from mol2image.train import run_training
from mol2image.utils import setup_logger

import os
import argparse

def setup_args():

    options = argparse.ArgumentParser()
    # save and directory options
    options.add_argument('--datadir', action="store", default="../data_cell_painting/images/")
    options.add_argument('--train-metafile', action="store", default="../data_cell_painting/metadata/datasplit_gen_train.csv")
    options.add_argument('--val-metafile', action="store", default="../data_cell_painting/metadata/datasplit_gen_test_easy.csv")
    options.add_argument('--featfile', action="store", default=None)
    options.add_argument('--save-dir', action="store", default='../results/cell_painting_cond/cond_glowmpn/glow/test')
    options.add_argument('--val-freq', action="store", default=100, type=int)
    options.add_argument('--save-freq', action="store", default=1000, type=int)
    options.add_argument('--seed', action="store", default=42, type=int)
    options.add_argument('--dataset', action="store", default='cell-painting')

    # model parameters
    options.add_argument('--model-type', action="store", default='cond_glowmpn')
    options.add_argument('--img-size', action="store", default=64, type=int)
    options.add_argument('--optimizer', action="store", dest="optimizer", default='adam')
    options.add_argument('--scheduler', action="store", dest="scheduler", default='none')
    options.add_argument('--n_flow', default=32, type=int, help='number of flows in each block')
    options.add_argument('--n_block', default=1, type=int, help='number of blocks')
    options.add_argument('--n_channel', default=5, type=int, help='number of channels')
    options.add_argument('--n_cond', default=512, type=int, help='number of conditional channels')
    options.add_argument('--pt-config-file', action="store", default=None)
    options.add_argument('--checkpoint', action="store", default=None)

    # training parameters
    options.add_argument('--batch-size', action="store", dest="batch_size", default=20, type=int)
    options.add_argument('--num-workers', action="store", dest="num_workers", default=8, type=int)
    options.add_argument('-lr', '--learning-rate', action="store", dest="learning_rate", default=1e-4, type=float)
    options.add_argument('--max-iter', action="store", default=200000, type=int)
    options.add_argument('--weight-decay', action="store", dest="weight_decay", default=1e-5, type=float)
    options.add_argument('--use-nce-loss', action="store_true", default=False)
    options.add_argument('--nce-T', action="store", default=0.07, type=float)
    options.add_argument('--nce-weight', action="store", default=1, type=float)

    # generation parameters
    options.add_argument('--temp', default=1.0, type=float, help='temperature of sampling')
    options.add_argument('--n_sample', default=20, type=int, help='number of samples')

    # gpu options
    options.add_argument('--no-cuda', action="store_true", default=False)

    # debugging mode
    options.add_argument('--debug-mode', action="store_true", default=False)
    options.add_argument('--save-examples', action="store_true", default=False)

    return options.parse_args()


if __name__ == "__main__":
    args = setup_args()
    args.use_gpu = not args.no_cuda
    os.makedirs(os.path.join(args.save_dir, "models"), exist_ok=True)
    os.makedirs(os.path.join(args.save_dir, "examples"), exist_ok=True)
    logger = setup_logger(name="training_log", save_dir=args.save_dir)
    logger.info(" ".join(sys.argv))
    logger.info(args)
    run_training(args, logger)
