from ..dataset import setup_dataset, data_sampler, CellPaintingDataset
from ..models.proglow import build_proglow_model
from ..utils import parse_json

import torch
from torchvision.utils import save_image

import numpy as np
import random
import os

def run_eval(args, logger):
    
    pt_config = parse_json(args.pt_config_file)
    z_shapes = pt_config['z_shapes']
    temp = pt_config['temp']

    net = build_proglow_model(pt_config['modules'])
    net.eval()

    if args.use_gpu:
        net.cuda()

    # generate latent variables
    z_sample = []
    torch.manual_seed(args.seed)
    for z,t in zip(z_shapes, temp):
        z_new = torch.randn(args.n_sample, *z) * t
        z_sample.append(z_new.cuda() if args.use_gpu else z_new)

    with torch.no_grad():
        img = net.reverse(z_sample).cpu().data

    n_channel = img.size(1)

    if n_channel == 3:
        savefile = os.path.join(args.save_dir, 'examples/%s.png' % '_'.join([f"{10*t:.2f}" for t in temp]))
        save_image(img, savefile, normalize=True, nrow=10, range=(-0.5, 0.5))
    else:
        for ch in range(5):
            savefile = os.path.join(args.save_dir, 'examples/%s_%s.png' % (ch, '_'.join([f"{10*t:.2f}" for t in temp])))
            ch_img = img[:,ch:ch+1,:,:]
            save_image(ch_img, savefile, normalize=True, nrow=10, range=(-0.5, 0.5))

    logger.info("Saved images at %s" % savefile)
