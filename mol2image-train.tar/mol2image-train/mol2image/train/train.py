from ..dataset import setup_dataloaders
from ..models import setup_model, calc_loss, calc_z_shapes, contrastive_loss
from ..utils import save_checkpoint, setup_optimizer, setup_lr_scheduler, parse_json, generate_config_file

import torch
from torchvision.utils import save_image

import numpy as np
from tqdm import tqdm
import random
import os

def run_eval(args, logger):
    pt_config = parse_json(args.pt_config_file) if args.pt_config_file else None

    net = setup_model(args=args, pt_config=pt_config)
    logger.debug(net)
    
    if args.use_gpu:
        net.cuda()

    _, testloader = setup_dataloaders(args)
        
    net.eval()
    total_log_p, total_logdet, total_images = 0, 0, 0

    for sample, cond in tqdm(testloader):
        batch_size = sample.size(0)

        if args.use_gpu:
            sample = sample.cuda()
            try:
                cond = cond.cuda() if 'cond' in args.model_type else None
            except AttributeError:
                pass

        with torch.no_grad():
            log_p, logdet, _ = net(sample, cond) if 'cond' in args.model_type else net(sample)
            loss, log_p, logdet = calc_loss(log_p=log_p, logdet=logdet, image_size=args.img_size, n_channel=args.n_channel)

        total_log_p += log_p.item()*batch_size
        total_logdet += logdet.item()*batch_size
        total_images += batch_size

    logger.info(f'Validation Result: logP: {(total_log_p/total_images):.5f}, logdet: {(total_logdet/total_images):.5f}')


def run_training(args, logger):
    
    # seed run
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    if args.use_gpu:
        torch.cuda.manual_seed(args.seed)

    pt_config = parse_json(args.pt_config_file) if args.pt_config_file else None

    net = setup_model(args=args, pt_config=pt_config)
    logger.info(net)
    
    if args.use_gpu:
        net.cuda()

    trainloader, testloader = setup_dataloaders(args)
    optimizer = setup_optimizer(name=args.optimizer, param_list=[{'params': net.parameters(),
                                                                    'lr': args.learning_rate,
                                                                    'weight_decay': args.weight_decay}])

    z_sample = []
    z_shapes = calc_z_shapes(args.n_channel, args.img_size, args.n_flow, args.n_block, args.model_type)
    temp = [args.temp for _ in z_shapes]

    if pt_config:
        z_shapes += pt_config['z_shapes']
        temp += pt_config['temp']

    # save config file
    generate_config_file(args, pt_config, z_shapes, model_type=args.model_type, temp=temp)

    # generate latent variables
    for z,t in zip(z_shapes, temp):
        z_new = torch.randn(args.n_sample, *z) * t
        z_sample.append(z_new.cuda() if args.use_gpu else z_new)

    for it in range(args.max_iter):
        net.train()
        logger.debug(it)

        # train
        if 'cond_' in args.model_type: # model is conditional
            sample, cond = next(trainloader)
            if args.use_gpu:
                sample = sample.cuda()
                try:
                    cond = cond.cuda()
                except AttributeError:
                    pass
            log_p, logdet, latents = net(sample, cond=cond)

        else:
            sample, _ = next(trainloader)
            if args.use_gpu:
                sample = sample.cuda()
            log_p, logdet, _ = net(sample)

        loss, log_p, logdet = calc_loss(log_p=log_p, logdet=logdet, image_size=args.img_size, n_channel=args.n_channel)

        if args.use_nce_loss:
            nce_loss = contrastive_loss(latents, net.get_mpn_projection(cond), T=args.nce_T)
            loss += args.nce_weight*nce_loss

        if not np.isfinite(loss.item()):
            logger.debug('WARNING: Got loss = NaN in iteration %s, not backpropagating' % it)
        else:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # save examples
        if args.save_examples:
            with torch.no_grad():
                net.eval()
                img = net.reverse(z_sample).cpu().data

            if 'cell-painting' in args.dataset:
                for ch in range(5):
                    ch_img = img[:,ch:ch+1,:,:]
                    save_image(ch_img, os.path.join(args.save_dir, 'examples/%s_%s.png' % (str(it+1).zfill(6), ch)), 
                               normalize=True, nrow=10, range=(-0.5, 0.5))
            else:
                save_image(img, os.path.join(args.save_dir, 'examples/%s.png' % (str(it+1).zfill(6))), 
                           normalize=True, nrow=10, range=(-0.5, 0.5))
        # log results
        if it % 100 == 0:
            logger.info(f'Iteration: {it}')
            try:
                logger.info(f'Loss: {loss.item():.5f}, logP: {log_p.item():.5f}, logdet: {logdet.item():.5f}, nce:{nce_loss.item():.5f}')
            except NameError:
                logger.info(f'Loss: {loss.item():.5f}, logP: {log_p.item():.5f}, logdet: {logdet.item():.5f}')
                

        # validation
        if it % args.val_freq == 0:
            if testloader is not None:
                net.eval()
                total_log_p, total_logdet, total_images, total_nce = 0, 0, 0, 0

                for sample, cond in testloader:
                    batch_size = sample.size(0)

                    if args.use_gpu:
                        sample = sample.cuda()
                        try:
                            cond = cond.cuda() if 'cond' in args.model_type else None
                        except AttributeError:
                            pass

                    with torch.no_grad():
                        log_p, logdet, latents = net(sample, cond) if 'cond' in args.model_type else net(sample)
                        loss, log_p, logdet = calc_loss(log_p=log_p, logdet=logdet, image_size=args.img_size, n_channel=args.n_channel)

                        if args.use_nce_loss:
                            nce_loss = contrastive_loss(latents, net.get_mpn_projection(cond), T=args.nce_T)
                            loss += args.nce_weight*nce_loss
                            total_nce += nce_loss.item()*batch_size

                    total_log_p += log_p.item()*batch_size
                    total_logdet += logdet.item()*batch_size
                    total_images += batch_size

                logger.info(f'Validation: {it}')
                logger.info(f'logP: {(total_log_p/total_images):.5f}, logdet: {(total_logdet/total_images):.5f}, nce:{(total_nce/total_images):.5f}')
            
        if it % args.save_freq == 0:
            # checkpoint model
            if 'proglow' in args.model_type:
                current_state = {'state_dict': net.cpu().blocks.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': None}
                try:
                    current_state['mol_embedding_net'] = net.cpu().cond_embedding.state_dict()
                except AttributeError:
                    pass
                try:
                    current_state['mol_reduce_net'] = net.cpu().cond_reduce.state_dict()
                except AttributeError:
                    pass
            else:
                current_state = {'state_dict': net.cpu().state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': None}
            save_checkpoint(current_state=current_state, filename=os.path.join(args.save_dir, "models/iter_%s.pth" % it))

            if args.use_gpu:
                net.cuda()
