from .glow import run_training as train_glow
from .proglow import run_training as train_proglow
from .train import run_training, run_eval
