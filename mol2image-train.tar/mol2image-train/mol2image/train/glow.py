from ..dataset import setup_dataset, data_sampler, CellPaintingDataset
from ..models import Glow
from ..utils import save_checkpoint, load_checkpoint, setup_optimizer, setup_lr_scheduler, generate_config_file

import torch
from torchvision.utils import save_image

import numpy as np
import random
import os

def calc_z_shapes(n_channel, input_size, n_flow, n_block):
    z_shapes = []

    for i in range(n_block - 1):
        input_size //= 2
        n_channel *= 2

        z_shapes.append((n_channel, input_size, input_size))

    input_size //= 2
    z_shapes.append((n_channel * 4, input_size, input_size))

    return z_shapes

def calc_loss(log_p, logdet, image_size, n_channel=3, n_bins=32):
    n_pixel = image_size * image_size * n_channel
    log_p = log_p.mean()
    logdet = logdet.mean()

    C = -np.log(n_bins) * n_pixel

    loss = C - logdet - log_p

    return (
        loss / (np.log(2) * n_pixel),
        log_p / (np.log(2) * n_pixel),
        logdet / (np.log(2) * n_pixel),
    )

def run_training(args, logger):
    
    # seed run
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    if args.use_gpu:
        torch.cuda.manual_seed(args.seed)

    net = Glow(args.n_channel, args.n_flow, args.n_block, affine=True, conv_lu=True)
    logger.info(net)
    
    if args.use_gpu:
        net.cuda()

    if args.dataset == 'celebA':
        trainset = setup_dataset(path=args.datadir, image_size=args.img_size)
    elif args.dataset == 'cell-painting':
        trainset = CellPaintingDataset(datadir=args.datadir, metafile=args.metafile, img_size=args.img_size)

    trainloader = iter(data_sampler(dataset=trainset, batch_size=args.batch_size, num_workers=args.num_workers))

    optimizer = setup_optimizer(name=args.optimizer, param_list=[{'params': net.parameters(),
                                                                    'lr': args.learning_rate,}])

    z_sample = []
    z_shapes = calc_z_shapes(args.n_channel, args.img_size, args.n_flow, args.n_block)
    temp = [args.temp for _ in z_shapes]

    # save config file
    generate_config_file(args, None, z_shapes, model_type='glow', temp=temp)
    
    for z,t in zip(z_shapes, temp):
        z_new = torch.randn(args.n_sample, *z) * t
        z_sample.append(z_new.cuda() if args.use_gpu else z_new)

    for it in range(args.max_iter):
        logger.debug(it)
        # train
        sample, _ = next(trainloader)
        if args.use_gpu:
            sample = sample.cuda()
        log_p, logdet, _ = net(sample)

        loss, log_p, logdet = calc_loss(log_p=log_p, logdet=logdet, image_size=args.img_size, n_channel=args.n_channel)

        if not np.isfinite(loss.item()):
            logger.debug('WARNING: Got loss = NaN in iteration %s, not backpropagating' % it)
        else:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # save examples
        if it % 100 == 0:
            with torch.no_grad():
                img = net.reverse(z_sample).cpu().data

            if args.dataset == 'celebA':
                save_image(img, os.path.join(args.save_dir, 'examples/%s.png' % (str(it+1).zfill(6))), 
                           normalize=True, nrow=10, range=(-0.5, 0.5))
            elif args.dataset == 'cell-painting':
                for ch in range(5):
                    ch_img = img[:,ch:ch+1,:,:]
                    save_image(ch_img, os.path.join(args.save_dir, 'examples/%s_%s.png' % (str(it+1).zfill(6), ch)), 
                               normalize=True, nrow=10, range=(-0.5, 0.5))

            logger.info(f'Iteration: {it}')
            logger.info(f'Loss: {loss.item():.5f}, logP: {log_p.item():.5f}, logdet: {logdet.item():.5f}')

        # checkpoint model
        if it % args.save_freq == 0:
            current_state = {'state_dict': net.cpu().state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': None}
            save_checkpoint(current_state=current_state, filename=os.path.join(args.save_dir, "models/iter_%s.pth" % it))

            if args.use_gpu:
                net.cuda()
